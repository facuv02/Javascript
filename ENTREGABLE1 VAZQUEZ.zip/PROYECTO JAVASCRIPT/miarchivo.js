// Variables globales  
let numeroSecreto;  
let intentos;  

// Función para iniciar el juego  
function iniciarJuego() {  
    numeroSecreto = Math.floor(Math.random() * 100) + 1; // Número aleatorio entre 1 y 100  
    intentos = 0;  
    alert("He pensado un número entre 1 y 100. ¡Intenta adivinarlo!");  
    adivinarNumero();  
}  

// Función para manejar la adivinanza  
function adivinarNumero() {  
    let guess;  
    let adivinado = false; // Variable para controlar si se ha adivinado el número  

    while (!adivinado) { // Bucle que se repite hasta que se adivine el número  
        guess = prompt("Introduce tu adivinanza:");  

        // Validar que la entrada es un número  
        if (isNaN(guess) || guess < 1 || guess > 100) {  
            alert("Por favor, ingresa un número válido entre 1 y 100.");  
            continue; // Continúa con el siguiente ciclo del bucle  
        }  

        intentos++;  
        guess = Number(guess);  

        // Comparar la adivinanza con el número secreto  
        if (guess === numeroSecreto) {  
            alert(`¡Felicidades! Adivinaste el número ${numeroSecreto} en ${intentos} intentos.`);  
            adivinado = true; // Cambiar el estado a adivinado para salir del bucle  
        } else if (guess < numeroSecreto) {  
            alert("El número es mayor. Inténtalo de nuevo.");  
        } else {  
            alert("El número es menor. Inténtalo de nuevo.");  
        }  
    }  
}  

// Iniciar el juego llamando a la función  
iniciarJuego();  